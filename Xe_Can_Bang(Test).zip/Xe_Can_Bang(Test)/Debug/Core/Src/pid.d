Core/Src/pid.o: ../Core/Src/pid.c ../Core/Inc/pid.h \
 ../Core/Inc/balance_profile.h
../Core/Inc/pid.h:
../Core/Inc/balance_profile.h:
