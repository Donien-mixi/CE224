/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "robot_fsm.h"
#include "buzzer_led.h"
#include "esp32_comm.h"
#include "bmi160.h"
#include "motor.h"
#include "hardware_test.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  /* [TEST RIÊNG CẢM BIẾN BMI160 — chạy độc lập, KHÔNG vào vòng lặp cân bằng]
   * Bỏ dấu comment dòng dưới để quét I2C, đọc CHIP_ID và in dữ liệu IMU ra USART1 (PB6 TX, 115200).
   * LƯU Ý: hàm này lặp vô hạn (blocking) — dùng khi test cảm biến riêng, không cần động cơ/web. */
  // BMI160_Test_Run();

  /* [CHẾ ĐỘ TEST ĐỘNG CƠ LIÊN TỤC & ĐO ÁP VOM]
   * Bỏ dấu comment dòng dưới nếu muốn xe chạy lặp vô hạn (Trái 2s -> Phải 2s -> Cả 2 2s)
   * để quan sát động cơ quay hoặc dùng đồng hồ VOM đo điện áp kích tại PA8..PA11: */
  // Motor_Test_Run();

  /* Khởi tạo toàn bộ driver linh kiện và thuật toán */
  Robot_Init();

  /* Bắt đầu ngắt định thời nhịp tim 200Hz (5ms) trên Timer 4 */
  HAL_TIM_Base_Start_IT(&htim4);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


  while (1)
  {
    /* UART parsing stays preemptible. Parser masks IRQ only for the command commit. */
    ESP32_Comm_Process();
    HardwareTest_Service();

    /* 2. Xử lý yêu cầu hiệu chuẩn lại IMU từ web ($CALIB) — chạy NGOÀI ngắt 200Hz */
    if (ESP32_Comm_GetCommand()->trigger_calib) {
        ESP32_Comm_GetCommand()->trigger_calib = 0;
        Robot_RecalibrateIMU();
        ESP32_Comm_FlushRx();   /* Xóa byte tồn đọng trong lúc hiệu chuẩn */
    }

    /* 3. Cập nhật hiệu ứng Còi và LED trạng thái (phi phong bế) */
    BuzzerLED_Update(HAL_GetTick());

    Robot_BalanceService();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 200;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
  * @brief  printf redirect qua USART1 — GHI TRỰC TIẾP THANH GHI, KHÔNG DÙNG HAL.
  * LÝ DO: USART1 dùng chung cho DMA Telemetry ($TEL) và DMA RX lệnh ($CMD).
  *        Nếu dùng HAL_UART_Transmit() sẽ xung đột trạng thái gState với DMA.
  *        Ghi thẳng USART1->DR chỉ an toàn cho các hàm test blocking
  *        (BMI160_Test_Run) chạy TRƯỚC vòng lặp chính, khi telemetry chưa hoạt động.
  */
int __io_putchar(int ch)
{
  while ((USART1->SR & USART_SR_TXE) == 0U) { }
  USART1->DR = (uint8_t)(ch & 0xFFU);
  return ch;
}

/**
  * @brief  Ngắt tràn Timer định thời (Callback từ HAL_TIM_IRQHandler)
  * @param  htim: Con trỏ Timer gây ngắt
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM4) {
    /* Thực thi vòng lặp điều khiển phản hồi Cascade PID 200Hz */
    Robot_ControlLoop_200Hz();
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
