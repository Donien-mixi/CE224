#ifndef R12_DRIVE_REFERENCE_H
#define R12_DRIVE_REFERENCE_H
/* EXPERIMENTAL reference extension. Original R12 gains/observer/allocator unchanged.
 * Units: m, m/s, rad, rad/s. No HAL, no plant truth. Test in simulation first.
 * ref[0..3]=x,v,psi,yaw-rate. Pose references are relative to the ARM origin.
 */
#include "phase1_catalog_control.h"
#include "r12_drive_protocol.h"
static inline int r12_step_reference(const float *in,float *s,const float *ref,float *out){
 for(int i=0;i<7;i++)if(!isfinite(in[i]))return 0;
 for(int i=0;i<4;i++)if(!isfinite(ref[i]))return 0;
 for(int i=0;i<CAT_N+3;i++)if(!isfinite(s[i]))return 0;
 float z[CAT_N],err[4];
 for(int i=0;i<CAT_N;i++){
  float v=CAT_B[i]*s[CAT_N+2];for(int j=0;j<CAT_N;j++)v+=CAT_A[i*CAT_N+j]*s[j];z[i]=v;
 }
 float measurement[4]={in[3]-CAT_PARAM[1]*s[CAT_N+1],.5f*(in[4]+in[5]),in[1],in[2]};
 for(int i=0;i<4;i++){err[i]=measurement[i];for(int j=0;j<CAT_N;j++)err[i]-=CAT_H[i*CAT_N+j]*z[j];}
 for(int i=0;i<CAT_N;i++){for(int j=0;j<4;j++)z[i]+=CAT_L[i*4+j]*err[j];s[i]=z[i];}
 float theta0=in[0]+.03f*in[1],theta=theta0+CAT_PARAM[11]*(z[2]-theta0);
 float omega=in[1]+CAT_PARAM[11]*(z[3]-in[1]);
 float x[4]={in[3]+CAT_PARAM[1]*(theta-s[CAT_N+1]),.5f*(in[4]+in[5])+CAT_PARAM[1]*omega,theta,omega};
 x[0]-=ref[0];x[1]-=ref[1];
 float request=0;for(int i=0;i<4;i++)request+=CAT_K[i]*x[i];
 float desired=cat_clip(request,CAT_PARAM[4]);
 float psi=in[6]/CAT_PARAM[0]-ref[2],rate=(in[5]-in[4])/CAT_PARAM[0]-ref[3];
 float ci=cat_clip(s[CAT_N]+CAT_PARAM[7]*psi*.005f,CAT_PARAM[8]);
 float unsat=-CAT_PARAM[5]*psi-CAT_PARAM[6]*rate-ci;
 cat_allocate(desired,cat_clip(unsat,CAT_PARAM[9]),in+4,out);
 if(fabsf(unsat-out[2])<.0001f||(unsat-out[2])*psi>0)s[CAT_N]=ci;
 else cat_allocate(desired,cat_clip(-CAT_PARAM[5]*psi-CAT_PARAM[6]*rate-s[CAT_N],CAT_PARAM[9]),in+4,out);
 s[CAT_N+2]=out[3];
 for(int i=0;i<CAT_N+3;i++)if(!isfinite(s[i]))return 0;
 return isfinite(out[0])&&isfinite(out[1])&&fabsf(out[0])<=2499&&fabsf(out[1])<=2499;
}

static inline float r12_approach(float old,float target,float step) {
 return old+cat_clip(target-old,step);
}
static inline void r12_reference_update(float *ref,const float *in,float v,float w) {
 /* Trial envelope only: 0.1 m/s, 0.2 rad/s; accel0.1 m/s2, yaw accel0.5 rad/s2. */
 ref[1]=r12_approach(ref[1],cat_clip(v,R12_DRIVE_MAX_V),.0005f);
 ref[3]=r12_approach(ref[3],cat_clip(w,R12_DRIVE_MAX_W),.0025f);
 ref[0]+=ref[1]*.005f;ref[2]+=ref[3]*.005f;
 ref[0]=in[3]+cat_clip(ref[0]-in[3],.12f);
 float psi=in[6]/CAT_PARAM[0];ref[2]=psi+cat_clip(ref[2]-psi,.35f);
}
#endif
