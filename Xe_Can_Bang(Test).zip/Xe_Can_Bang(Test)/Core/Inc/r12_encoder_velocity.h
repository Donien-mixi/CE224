#ifndef R12_ENCODER_VELOCITY_H
#define R12_ENCODER_VELOCITY_H
/* Experimental R12 measurement patch. 200Hz, 3-sample displacement window.
 * Keeps integer ticks, motor signs and PPR. Adjusts the LPF pole after the window.
 * Window adds5ms; beta2/3 adds10ms: same low-frequency delay15ms as old beta.75.
 * Full frequency response differs; validate with the R12 observer.
 */
#include <stdint.h>
#include <math.h>
#define R12_ENCODER_WINDOW 3U
#define R12_ENCODER_BETA (2.0f/3.0f)
typedef struct {
    int32_t delta[R12_ENCODER_WINDOW];
    uint32_t next;
    float filtered;
} R12EncoderVelocity;
static inline void R12EncoderVelocity_Reset(R12EncoderVelocity *s) {
    for(uint32_t i=0;i<R12_ENCODER_WINDOW;i++)s->delta[i]=0;
    s->next=0;s->filtered=0;
}
/* Caller handles uint16 timer wrap and right-wheel sign before this function.
 * Window is zero-padded at reset, matching the stationary ARM condition.
 * All intervals must use the fixed control period, as current Encoder_Update does.
 */
static inline int R12EncoderVelocity_Update(R12EncoderVelocity *s,int32_t delta,
        float dt,float metres_per_tick,float beta,float *out) {
    if(!isfinite(dt)||dt<.0001f||dt>.02f||!isfinite(metres_per_tick)||metres_per_tick<=0||
       !isfinite(beta)||beta<0||beta>=1||s->next>=R12_ENCODER_WINDOW||
       delta < -32768 || delta > 32768) {*out=0;return 0;}
    s->delta[s->next]=delta;s->next=(s->next+1U)%R12_ENCODER_WINDOW;
    int32_t total=0;for(uint32_t i=0;i<R12_ENCODER_WINDOW;i++)total+=s->delta[i];
    float velocity=(float)total*metres_per_tick/((float)R12_ENCODER_WINDOW*dt);
    s->filtered=(1-beta)*velocity+beta*s->filtered;*out=s->filtered;
    return isfinite(s->filtered);
}
#endif
