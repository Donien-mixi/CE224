# ESP32-S3 — Cấu hình và vận hành

## Build và nạp

1. Cài ESP32 core 3.3.11 và WebSockets 2.7.2 của Markus Sattler trong Arduino IDE.
2. Mở `ESP32_S3_Gateway.ino`.
3. Chọn **ESP32S3 Dev Module** và cổng COM của board.
4. Thiết lập:

| Mục | Giá trị |
|---|---|
| USB CDC On Boot | Enabled |
| Flash Size | 16 MB |
| Partition Scheme | 16M Flash, 3MB APP / khoảng 9,9MB FATFS |
| PSRAM | OPI PSRAM |

5. Chạy **Verify**, xử lý lỗi rồi **Upload**.
6. Nạp STM32 từ cùng bộ nguồn R12 D2.

## Kết nối UART

| ESP32 | STM32 |
|---|---|
| GPIO18 RX | PB6 USART1 TX |
| GPIO17 TX | PB7 USART1 RX |
| GND | GND |

UART: 115200 baud, 8N1. Giữ đồng bộ `balance_wire.h` và `r12_drive_protocol.h` giữa hai board.

## Điều khiển

1. Kết nối Wi-Fi `TWIP_RACER_S3`, mật khẩu `12345678`.
2. Mở `http://192.168.4.1`.
3. Kiểm từng bánh khi kê cao trước khi thử cân bằng trên nền.
4. Bấm BẬT CÂN BẰNG khi xe đứng yên trong điều kiện READY.
5. Giữ nút để tiến/lùi/quay; nhả để giảm tốc. Nút đỏ cắt motor.
6. Giữ trang ở phía trước; ẩn trang hoặc mất kết nối có thể gửi STOP.
7. Dừng motor, đợi ít nhất 2 giây rồi tải log TXT trước khi xóa hoặc tắt nguồn.

Nếu hết tuổi lệnh, DỪNG và ARM lại để tiếp tục chạy. Giới hạn bản thử: 0,10 m/s, 0,20 rad/s và quãng encoder 30 cm.

Trang đo linh kiện: `/calibration` và `/wheel-tests`. Sau khi vào chế độ đo khóa, khởi động lại STM32 để trở về vận hành.

[Hướng dẫn đầy đủ](../README_GD2_R12.md).
