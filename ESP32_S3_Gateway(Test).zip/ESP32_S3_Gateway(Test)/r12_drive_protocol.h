#ifndef R12_DRIVE_PROTOCOL_H
#define R12_DRIVE_PROTOCOL_H
/* Protocol D2. Packet body excludes the trailing '*' on STM32.
 * Epoch is changed for every ARM. Sequence is strictly increasing per epoch.
 * Shared verbatim with ESP32. No HAL/Arduino dependencies. */
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define R12_DRIVE_BUILD "BAL-20261017-R12-D2-EXP"
#define R12_DRIVE_MAX_V .10f
#define R12_DRIVE_MAX_W .20f
#define R12_DRIVE_COMMAND_MS 300U
typedef struct { uint32_t epoch,seq; float v,w; } R12DrivePacket;
static inline int r12_parse_u32(const char **p,uint32_t *out) {
 const char *s=*p;uint32_t n=0;
 if(*s<'0'||*s>'9')return 0;
 do {unsigned d=(unsigned)(*s-'0');if(n>(2147483647U-d)/10U)return 0;n=n*10U+d;s++;}while(*s>='0'&&*s<='9');
 if(n==0)return 0;*p=s;*out=n;return 1;
}
static inline int r12_parse_float(const char **p,float *out) {
 const char *start=*p,*s=start;int digits=0;
 if(*s=='-'||*s=='+')s++;
 while(*s>='0'&&*s<='9'){digits++;s++;}
 if(*s=='.'){s++;while(*s>='0'&&*s<='9'){digits++;s++;}}
 if(!digits||s-start>16)return 0;
 char *end;float v=strtof(start,&end);
 if(end!=s||!isfinite(v))return 0;*p=s;*out=v;return 1;
}
static inline int r12_parse_arm(const char *s,uint32_t *epoch) {
 if(strncmp(s,"$ARM2,",6))return 0;s+=6;
 return r12_parse_u32(&s,epoch)&&!*s;
}
static inline int r12_parse_drive(const char *s,R12DrivePacket *out) {
 R12DrivePacket d;if(strncmp(s,"$D2,",4))return 0;s+=4;
 if(!r12_parse_u32(&s,&d.epoch)||*s++!=',')return 0;
 if(!r12_parse_u32(&s,&d.seq)||*s++!=',')return 0;
 if(!r12_parse_float(&s,&d.v)||*s++!=',')return 0;
 if(!r12_parse_float(&s,&d.w)||*s)return 0;
 if(fabsf(d.v)>R12_DRIVE_MAX_V||fabsf(d.w)>R12_DRIVE_MAX_W)return 0;
 *out=d;return 1;
}
typedef struct {
 uint32_t epoch,seq,last_ms;float v,w;uint8_t seen,expired;
} R12DriveCommand;
static inline void r12_command_reset(R12DriveCommand *c,uint32_t epoch,uint32_t now) {
 memset(c,0,sizeof(*c));c->epoch=epoch;c->last_ms=now;
}
static inline int r12_command_accept(R12DriveCommand *c,const R12DrivePacket *d,uint32_t now) {
 /* Expiry is latched even if a delayed packet arrives before the next IRQ. */
 if(c->seen && (uint32_t)(now-c->last_ms)>R12_DRIVE_COMMAND_MS)c->expired=1;
 if(!c->epoch||c->expired||d->epoch!=c->epoch||d->seq<=c->seq)return 0;
 c->seq=d->seq;c->v=d->v;c->w=d->w;c->last_ms=now;c->seen=1;return 1;
}
static inline void r12_command_poll(R12DriveCommand *c,uint32_t now) {
 if(c->seen && (uint32_t)(now-c->last_ms)>R12_DRIVE_COMMAND_MS)c->expired=1;
 if(c->expired)c->v=c->w=0;
}
#endif
