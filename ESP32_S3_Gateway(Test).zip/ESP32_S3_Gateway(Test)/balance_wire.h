#pragma once
#include <stdint.h>
/* Little endian IEEE754 float; CRC16 CCITT FFFF over all except crc.
 * D2 frame sync=0x5ca5. Decimated at 50Hz from 200Hz control. IMU ODR100Hz (not synchronised).
 * PWM is the output of this cycle; raw sensors and ticks precede that output.
 * ticks_r is the original hardware sign, before direction correction. */
typedef struct __attribute__((packed)) {
    uint16_t sync;
    uint32_t sequence, t_ms;
    uint16_t dt_us, execution_us;
    int16_t gx, gy, gz, ax, ay, az;
    int32_t ticks_l, ticks_r;
    int16_t pwm_l, pwm_r;
    float pitch, gyro, v_l, v_r, x, v_cmd, theta_cmd, pwm_base, integral;
    uint16_t fault, dropped;
    uint8_t state, ready;
    float x_ref,v_ref,psi_ref,w_ref,v_request,w_request;
    uint32_t drive_epoch,drive_sequence,drive_age_ms;
    uint8_t drive_status,protocol; // status0 HOLD/no command,1 fresh,2 expiry latched; protocol2
    uint16_t crc;
} BalanceFrame;
#ifdef __cplusplus
static_assert(sizeof(BalanceFrame)==120,"balance wire layout");
#else
_Static_assert(sizeof(BalanceFrame)==120,"balance wire layout");
#endif
