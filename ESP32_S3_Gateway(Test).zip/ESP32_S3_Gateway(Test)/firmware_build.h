#pragma once
// Shared by the embedded page and HTTP diagnostic endpoint.
#define TWIP_WEB_BUILD "TWIP-WEB-20261017-R12-D2-EXP"
#define TWIP_WEB_PATH "/ui/r12-d2"
